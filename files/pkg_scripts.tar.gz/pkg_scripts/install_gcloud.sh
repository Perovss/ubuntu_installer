#!/usr/bin/env bash

set -eo pipefail

test -z $DEBUG_TOOL_INSTALL_SCRIPT || set -ex

TOOL_NAME="gcloud"
INSTALL_DIR="${HOME}/tools/${TOOL_NAME}"
REPO="ssh://git@gitea.soft-machine.ru:2222/Infra/pkg-${TOOL_NAME}.git"
BINARY_NAME="${TOOL_NAME}"
PY_VER="3.7.2"
BIN_FILE="${TOOL_NAME}.bin"
TAR_NAME="${TOOL_NAME}_linux.tgz"
if [[ "$OSTYPE" == "darwin"* ]]
then
    TAR_NAME="${TOOL_NAME}_darwin.tgz"
fi
TOOL_VERSION=$1

echo -e "\n- check old installation"
if command -v gcloud 2>&1 1>/dev/null;
then
    gcloud_which=$(which gcloud)
    gcloud_dir=$(dirname $(dirname $gcloud_which))
    gcloud_dirname=$(dirname $gcloud_dir)
    gcloud_basename=$(basename $gcloud_dir)
    if [[ "$gcloud_which" != '/usr/local/bin/gcloud' ]]
    then
      echo -e "-- detected old installation"
      echo "which: $gcloud_which"
      echo "  dir: $gcloud_dirname"
      echo " base: $gcloud_basename"

      if ! [[ "$gcloud_dirname" =~ ^("$INSTALL_DIR/dist"|"$INSTALL_DIR/current")$ && "$gcloud_basename" =~ ^(gcloud$|gcloud-.*) ]]
      then
          echo "-- need del gcloud, backup:"
          mv -v $gcloud_dir "${gcloud_dir}.bak"
      fi
    fi
fi

echo -e "\n- install ${TOOL_NAME}..."

echo -e "\n-- calc version to install"
if test -z $TOOL_VERSION
then
   NEW_SHA_FULL=$(git ls-remote $REPO refs/heads/master | awk '{print $1}')
else
   NEW_SHA_FULL=$TOOL_VERSION
fi
NEW_SHA=$(echo $NEW_SHA_FULL | awk '{print substr($0,0,11)}')
INSTALL_SUBDIR="dist/${TOOL_NAME}-${NEW_SHA}"
VENV_NAME="${TOOL_NAME}-${NEW_SHA}"
DO_INSTALL=

echo -e "\n- check installed"
if test -f "${INSTALL_DIR}/${INSTALL_SUBDIR}/install_ok.txt"
then
    echo -e "\n-- tool already installed"
else
    echo -e "\n-- installing..."
    DO_INSTALL="yes"

    echo -e "\n-- download..."
    TMP="${INSTALL_DIR}/dist/${TOOL_NAME}_tmp"
    rm -rf $TMP
    mkdir -p $TMP
    cd $TMP
    git init
    git remote add origin $REPO
    git pull origin $NEW_SHA_FULL
    git checkout $FETCH_HEAD

    # install
    cd $INSTALL_DIR
    rm -rf $INSTALL_SUBDIR
    mkdir -p $INSTALL_SUBDIR
    tar -xf $TMP/$TAR_NAME -C $INSTALL_SUBDIR --strip-components 1
    cp -R $TMP/.git $INSTALL_SUBDIR/ #for updater

    # venv
    echo -e "\n-- install depends..."
    pyenv install -s $PY_VER
    echo $VENV_NAME > $INSTALL_SUBDIR/.py-version
    pyenv uninstall -f $VENV_NAME
    pyenv virtualenv -f $PY_VER $VENV_NAME

    # create .bashrc
    export CLOUDSDK_PYTHON=$HOME/.pyenv/versions/${PY_VER}/envs/${VENV_NAME}/bin/python
    export CLOUDSDK_PYTHON_SITEPACKAGES=$HOME/.pyenv/versions/${PY_VER}/envs/${VENV_NAME}/lib/python3.7
    GCLOUD_BASHRC="$HOME/.bashrc.d/gcloud.bashrc"
    echo "" > $GCLOUD_BASHRC
    echo "export CLOUDSDK_PYTHON=$CLOUDSDK_PYTHON" >> $GCLOUD_BASHRC
    echo "export CLOUDSDK_PYTHON_SITEPACKAGES=$CLOUDSDK_PYTHON_SITEPACKAGES" >> $GCLOUD_BASHRC
    echo "export INSTALL_DIR=$INSTALL_DIR/current" >> $GCLOUD_BASHRC
    echo 'test -f $INSTALL_DIR/path.bash.inc && source $INSTALL_DIR/path.bash.inc' >> $GCLOUD_BASHRC
    echo 'test -f $INSTALL_DIR/completion.bash.inc && source $INSTALL_DIR/completion.bash.inc' >> $GCLOUD_BASHRC

    echo "- install gcloud: add component 'gcr'"
    $INSTALL_DIR/$INSTALL_SUBDIR/bin/gcloud components install --quiet docker-credential-gcr
    export PATH=$INSTALL_DIR/$INSTALL_SUBDIR/bin:$PATH
    docker-credential-gcr configure-docker

    # create launcher link
    cd $INSTALL_DIR/$INSTALL_SUBDIR
    echo "#!/usr/bin/env bash" > $BIN_FILE
    echo "" >> $BIN_FILE
    echo "set -e" >> $BIN_FILE
    echo "TOOL_NAME=$TOOL_NAME" >> $BIN_FILE
    echo "TOOL_PATH=\"$INSTALL_DIR\"" >> $BIN_FILE
    echo 'UPDATES_FILE="$TOOL_PATH/updates.txt"' >> $BIN_FILE
    echo 'CHECK_UPDATE_FILE="$TOOL_PATH/update_check_time.txt"' >> $BIN_FILE
    echo '' >> $BIN_FILE
    echo 'if ! grep -qw $(date '+%Y_%m_%d') $CHECK_UPDATE_FILE 2>/dev/null;' >> $BIN_FILE
    echo 'then' >> $BIN_FILE
    echo '    if command -v updater 2>&1 1>/dev/null;' >> $BIN_FILE
    echo '    then' >> $BIN_FILE
    echo '        updater check $TOOL_NAME &>/dev/null &' >> $BIN_FILE
    echo '    fi' >> $BIN_FILE
    echo 'fi' >> $BIN_FILE
    echo 'test -f $UPDATES_FILE && cat $UPDATES_FILE || true' >> $BIN_FILE
    echo '$TOOL_PATH/current/bin/'${BINARY_NAME}' $@' >> $BIN_FILE
    echo 'test -f $UPDATES_FILE && cat $UPDATES_FILE || true' >> $BIN_FILE
    chmod +x $BIN_FILE

    echo -e "\n-- install pkg mark"
    touch "${INSTALL_DIR}/${INSTALL_SUBDIR}/install_ok.txt"
fi

echo -e "\n- update link current"
cd $INSTALL_DIR
rm -f current
ln -vs $INSTALL_SUBDIR current
ln -fvs $HOME/tools/gcloud/current $HOME/google-cloud-sdk #TODO fix

echo -e "\n- update link in PATH...(need sudo)"
sudo ln -vfs $INSTALL_DIR/current/$BIN_FILE /usr/local/bin/$TOOL_NAME

echo -e "\n- install success"
echo "Usage:"
echo "  $ ${TOOL_NAME} -h"
echo ""
echo "WARN: [!!!] to work you must execute 'source ~/.bashrc'"
echo ""
