#!/usr/bin/env bash

set -eo pipefail

test -z $DEBUG_TOOL_INSTALL_SCRIPT || set -ex

TOOL_NAME="get-k8s-config"
BINARY_NAME="get_k8s_config.py"
INSTALL_DIR="${HOME}/tools/${TOOL_NAME}"
REPO="ssh://git@gitea.soft-machine.ru:2222/Infra/${TOOL_NAME}.git"
PY_VER="3.9.0"
BIN_FILE="${TOOL_NAME}.bin"

echo -e "\n- install ${TOOL_NAME}..."

#-----------------------------------------------------------
# external depends

# bashrc.d
test -d $HOME/.bashrc.d || mkdir -p $HOME/.bashrc.d
BASHRC="$HOME/.bashrc"
if grep -q 'for file in $(find $HOME/.bashrc.d -maxdepth 1 ! -type d -iname "\*.bashrc" 2>/dev/null); do source "$file"; done;' $BASHRC
then
    echo -e "--- source bashrc.d existed, skip"
else
    echo -e "--- source bashrc.d insert"
    echo 'for file in $(find $HOME/.bashrc.d -maxdepth 1 ! -type d -iname "*.bashrc" 2>/dev/null); do source "$file"; done;' >> $BASHRC
fi

#-----------------------------------------------------------

NEW_SHA_FULL=$(git ls-remote $REPO refs/heads/master | awk '{print $1}')
NEW_SHA=$(echo $NEW_SHA_FULL | awk '{print substr($0,0,11)}')
INSTALL_SUBDIR="dist/${TOOL_NAME}-${NEW_SHA}"
VENV_NAME="${TOOL_NAME}-${NEW_SHA}"
SRV_NAME="port_forward_controller"
DO_INSTALL=
SED_CMD="sed -i"

if test -f "${INSTALL_DIR}/${INSTALL_SUBDIR}/install_ok.txt"
then
    echo -e "\n-- tool already installed"
else
    echo -e "\n-- installing..."
    DO_INSTALL="yes"

    # pyenv
    BASHRC_PYENV="$HOME/.bashrc.d/01_pyenv.bashrc"

    if [[ "$OSTYPE" == "darwin"* ]]
    then
        SED_CMD="sed -i .bak"
        echo -e "\n-- install external depends..."
        export HOMEBREW_NO_AUTO_UPDATE=1
        export LC_ALL=C.UTF-8
        export LANG=C.UTF-8
        brew upgrade pyenv || true
        # for py3 TODO
        brew install zlib sqlite || true
        export LDFLAGS="${LDFLAGS} -L/usr/local/opt/zlib/lib"
        export CPPFLAGS="${CPPFLAGS} -I/usr/local/opt/zlib/include"
        export LDFLAGS="${LDFLAGS} -L/usr/local/opt/sqlite/lib"
        export CPPFLAGS="${CPPFLAGS} -I/usr/local/opt/sqlite/include"
        export PKG_CONFIG_PATH="${PKG_CONFIG_PATH} /usr/local/opt/zlib/lib/pkgconfig"
        export PKG_CONFIG_PATH="${PKG_CONFIG_PATH} /usr/local/opt/sqlite/lib/pkgconfig"
    else
        #echo -e "\n-- install external depends (need sudo)..."
        echo -e "\n-- update pyenv..."
        pyenv update
    fi

    echo -e "\n-- download..."
    TMP="${INSTALL_DIR}/dist/${TOOL_NAME}_tmp"
    rm -rf $TMP
    mkdir -p $TMP
    cd $TMP
    git init
    git remote add origin $REPO
    git pull origin $NEW_SHA_FULL
    git checkout $FETCH_HEAD

    # install
    cd $INSTALL_DIR
    rm -rf $INSTALL_SUBDIR
    mv -v $TMP $INSTALL_SUBDIR

    # pip install
    echo -e "\n-- install depends..."
    pyenv install -s $PY_VER
    echo $VENV_NAME > $INSTALL_SUBDIR/.py-version
    pyenv uninstall -f $VENV_NAME
    pyenv virtualenv -f $PY_VER $VENV_NAME
    eval "$(pyenv init -)"
    REQ_FILE="$INSTALL_DIR/$INSTALL_SUBDIR/requirements.txt"
    if test -f "$REQ_FILE"
    then
        pyenv shell $VENV_NAME
        cd $INSTALL_DIR/$INSTALL_SUBDIR
        unset PYTHONPATH
        pip install -r $REQ_FILE
        pip freeze
        which python
        pyenv shell -
    fi

    # check venv
    #TODO
    #echo -e "\n-- check venv: show help"
    #bash -c "PYENV_VERSION=$VENV_NAME $INSTALL_DIR/$INSTALL_SUBDIR/${BINARY_NAME} -h"

    # create launcher link
    cd $INSTALL_DIR/$INSTALL_SUBDIR
    echo "#!/usr/bin/env bash" > $BIN_FILE
    echo "" >> $BIN_FILE
    echo "TOOL_NAME=$TOOL_NAME" >> $BIN_FILE
    echo "TOOL_PATH=\"$INSTALL_DIR\"" >> $BIN_FILE
    echo 'UPDATES_FILE="$TOOL_PATH/updates.txt"' >> $BIN_FILE
    echo 'CHECK_UPDATE_FILE="$TOOL_PATH/update_check_time.txt"' >> $BIN_FILE
    echo '' >> $BIN_FILE
    echo 'if ! grep -qw $(date '+%Y_%m_%d') $CHECK_UPDATE_FILE 2>/dev/null;' >> $BIN_FILE
    echo 'then' >> $BIN_FILE
    echo '    if command -v updater 2>&1 1>/dev/null;' >> $BIN_FILE
    echo '    then' >> $BIN_FILE
    echo '        $TOOL_PATH/current/updater.py check $TOOL_NAME &>/dev/null &' >> $BIN_FILE
    echo '    fi' >> $BIN_FILE
    echo 'fi' >> $BIN_FILE
    echo 'test -f $UPDATES_FILE && cat $UPDATES_FILE || true' >> $BIN_FILE
    echo 'PYENV_VERSION=$(cat $TOOL_PATH/current/.py-version) $TOOL_PATH/current/'${BINARY_NAME}' $@' >> $BIN_FILE
    echo 'test -f $UPDATES_FILE && cat $UPDATES_FILE || true' >> $BIN_FILE
    chmod +x $BIN_FILE

    echo -e "\n-- install pkg mark"
    cd $INSTALL_DIR/$INSTALL_SUBDIR
    touch "install_ok.txt"
fi

echo -e "\n- update link current"
cd $INSTALL_DIR
rm -f current
ln -vs $INSTALL_SUBDIR current

echo -e "\n- update link in PATH...(need sudo)"
sudo ln -vfs $INSTALL_DIR/current/$BIN_FILE /usr/local/bin/$TOOL_NAME

#TODO
#echo -e "\n- install success"
#echo "Usage:"
#echo "  $ ${TOOL_NAME} -h"
#echo ""
#echo "WARN: [!!!] to work you must execute 'source ~/.bashrc'"
#echo ""
