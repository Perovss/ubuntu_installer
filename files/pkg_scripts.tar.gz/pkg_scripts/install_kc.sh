#!/usr/bin/env bash

set -eo pipefail

test -z $DEBUG_TOOL_INSTALL_SCRIPT || set -ex

TOOL_NAME="kc"
INSTALL_DIR="${HOME}/tools/${TOOL_NAME}"
REPO="ssh://git@gitea.soft-machine.ru:2222/Infra/kc.git"
BIN_FILE="${TOOL_NAME}.bin"

echo -e "\n- install ${TOOL_NAME}..."

NEW_SHA_FULL=$(git ls-remote $REPO refs/heads/master | awk '{print $1}')
NEW_SHA=$(echo $NEW_SHA_FULL | awk '{print substr($0,0,11)}')
INSTALL_SUBDIR="dist/${TOOL_NAME}-${NEW_SHA}"
VENV_NAME="${TOOL_NAME}-${NEW_SHA}"
DO_INSTALL=

if test -f "${INSTALL_DIR}/${INSTALL_SUBDIR}/install_ok.txt"
then
    echo -e "\n-- tool already installed"
else
    echo -e "\n-- installing..."
    DO_INSTALL="yes"

    echo -e "\n-- download..."
    TMP="${INSTALL_DIR}/dist/${TOOL_NAME}_tmp"
    rm -rf $TMP
    mkdir -p $TMP
    cd $TMP
    git init
    git remote add origin $REPO
    git pull origin $NEW_SHA_FULL
    git checkout $FETCH_HEAD

    cd $INSTALL_DIR
    rm -rf $INSTALL_SUBDIR
    mv -v $TMP $INSTALL_SUBDIR

    # install
    cd $INSTALL_SUBDIR
    cp -v kc.bashrc "$HOME/.bashrc.d/kc.bashrc"
    test -d $HOME/.fzf || {
       git clone --depth 1 https://github.com/junegunn/fzf.git ~/.fzf
       $HOME/.fzf/install --key-bindings --completion --no-update-rc
       mv -v ~/.fzf.bash ~/.bashrc.d/fzf.bashrc
    }

    # create launcher link
    echo "#!/usr/bin/env bash" > $BIN_FILE
    echo "" >> $BIN_FILE
    echo "TOOL_PATH=\"$INSTALL_DIR\"" >> $BIN_FILE
    echo 'UPDATES_FILE="$TOOL_PATH/updates.txt"' >> $BIN_FILE
    echo 'test -f $UPDATES_FILE && cat $UPDATES_FILE || true' >> $BIN_FILE
    echo "source $INSTALL_DIR/current/fn_kc.bashrc" >> $BIN_FILE
    echo 'fn_kc $@' >> $BIN_FILE
    echo 'test -f $UPDATES_FILE && cat $UPDATES_FILE || true' >> $BIN_FILE
    chmod +x $BIN_FILE

    echo -e "\n-- install pkg mark"
    touch "${INSTALL_DIR}/${INSTALL_SUBDIR}/install_ok.txt"
fi

echo -e "\n- update link current"
cd $INSTALL_DIR
rm -f current
ln -vs $INSTALL_SUBDIR current

echo -e "\n- update link in PATH...(need sudo)"
sudo ln -vfs $INSTALL_DIR/current/$BIN_FILE /usr/local/bin/$TOOL_NAME

echo -e "\n- install success"
echo "Usage:"
echo "  $ ${TOOL_NAME} -h"
echo ""
echo "WARN: [!!!] to work you must execute 'source ~/.bashrc'"
echo ""
