#!/usr/bin/env bash

set -eo pipefail

TOOL_NAME="kubectl"
INSTALL_DIR="${HOME}/tools/${TOOL_NAME}"
REPO="ssh://git@gitea.soft-machine.ru:2222/Infra/pkg-${TOOL_NAME}.git"
BINARY_NAME="${TOOL_NAME}_linux"
BIN_FILE="${TOOL_NAME}.bin"
if [[ "$OSTYPE" == "darwin"* ]]
then
    BINARY_NAME="${TOOL_NAME}_darwin"
fi

echo -e "\n- install ${TOOL_NAME}..."

NEW_SHA_FULL=$(git ls-remote $REPO refs/heads/master | awk '{print $1}')
NEW_SHA=$(echo $NEW_SHA_FULL | awk '{print substr($0,0,11)}')
INSTALL_SUBDIR="dist/${TOOL_NAME}-${NEW_SHA}"

if test -f "${INSTALL_DIR}/${INSTALL_SUBDIR}/install_ok.txt"
then
    echo -e "\n-- tool already installed"
else
    echo -e "\n-- download..."
    TMP="${INSTALL_DIR}/dist/${TOOL_NAME}_tmp"
    rm -rf $TMP
    mkdir -p $TMP
    cd $TMP
    git init
    git remote add origin $REPO
    git pull origin $NEW_SHA_FULL
    git checkout $FETCH_HEAD

    # install
    cd $INSTALL_DIR
    rm -rf $INSTALL_SUBDIR
    mv -v $TMP $INSTALL_SUBDIR

    # create launcher link
    cd $INSTALL_DIR/$INSTALL_SUBDIR
    echo "#!/usr/bin/env bash" > $BIN_FILE
    echo "" >> $BIN_FILE
    echo "TOOL_NAME=$TOOL_NAME" >> $BIN_FILE
    echo "TOOL_PATH=\"$INSTALL_DIR\"" >> $BIN_FILE
    echo 'UPDATES_FILE="$TOOL_PATH/updates.txt"' >> $BIN_FILE
    echo 'CHECK_UPDATE_FILE="$TOOL_PATH/update_check_time.txt"' >> $BIN_FILE
    echo '' >> $BIN_FILE
    echo 'if ! grep -qw $(date '+%Y_%m_%d') $CHECK_UPDATE_FILE 2>/dev/null;' >> $BIN_FILE
    echo 'then' >> $BIN_FILE
    echo '    if command -v updater 2>&1 1>/dev/null;' >> $BIN_FILE
    echo '    then' >> $BIN_FILE
    echo '        updater check $TOOL_NAME &>/dev/null &' >> $BIN_FILE
    echo '    fi' >> $BIN_FILE
    echo 'fi' >> $BIN_FILE
    echo 'test -f $UPDATES_FILE && cat $UPDATES_FILE || true' >> $BIN_FILE
    echo '$TOOL_PATH/current/'${BINARY_NAME}' $@' >> $BIN_FILE
    echo 'test -f $UPDATES_FILE && cat $UPDATES_FILE || true' >> $BIN_FILE
    chmod +x $BIN_FILE

    # create completion .bashrc
    mkdir -p $HOME/.bashrc.d/
    BASHRC=$HOME/.bashrc.d/kubectl.bashrc
    echo '' > $BASHRC
    echo '#!/usr/bin/env bash' >> $BASHRC
    echo '' >> $BASHRC
    echo 'if command -v kubectl &>/dev/null; then' >> $BASHRC
    echo '  source <(kubectl completion bash)' >> $BASHRC
    echo '  source <(kubectl completion bash | sed "s/kubectl/k/g")' >> $BASHRC
    echo '  alias k="kubectl"' >> $BASHRC
    echo 'fi' >> $BASHRC

    echo -e "\n-- install pkg mark"
    touch "${INSTALL_DIR}/${INSTALL_SUBDIR}/install_ok.txt"
fi

echo -e "\n- update link current"
cd $INSTALL_DIR
rm -f current
ln -vs $INSTALL_SUBDIR current

echo -e "\n- update link in PATH...(need sudo)"
sudo ln -vfs $INSTALL_DIR/current/$BINARY_NAME /usr/local/bin/$TOOL_NAME

echo -e "\n- install success"
echo "Usage:"
echo "  $ ${TOOL_NAME} -h"
echo ""
echo "WARN: [!!!] to bash-completion work you must execute 'source ~/.bashrc'"
echo ""
